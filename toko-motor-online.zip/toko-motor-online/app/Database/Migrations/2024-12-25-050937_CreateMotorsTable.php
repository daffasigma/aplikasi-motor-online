<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateMotorTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'=>[
                'type'=>'INT',
                'constraint'=> 11,
                'auto_increment'=> true,
            ],
            'merek'=>[
                'type'=>'VARCHAR',
                'constraint'=> 225,
            ],
            'tipe'=>[
                'type'=>'VARCHAR',
                'constraint'=> 225,
            ],
            'tahun'=>[
                'type'=>'INT',
                'constraint'=> 5,
            ],
            'warna'=>[
                'type'=>'VARCHAR',
                'constraint'=> 50,
            ],
            'harga'=>[
                'type'=>'INT',
                'constraint'=> 16,
            ],
            'mesin'=>[
                'type'=>'VARCHAR',
                'constraint'=> 50,
            ],
            'cover'=>[
                'type'=>'VARCHAR',
                'constraint'=> 250,
            ]
        ]);

        $this->forge->addKey('id', true);
        $this->forge->createTable('motor');
    }

    public function down()
    {
        $this->forge->dropTable('motor');
    }
}
