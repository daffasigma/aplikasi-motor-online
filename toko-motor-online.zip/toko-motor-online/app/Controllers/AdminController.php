<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\MotorsModel;
use CodeIgniter\HTTP\ResponseInterface;

class AdminController extends BaseController
{
    public function index()
    {
        return view('admin/dashboard');
    }

    public function daftarMotor()
    {
        $motorModel = new MotorsModel();

        $data['motor'] = $motorModel->findAll();

        return view('admin/daftar-motor', $data);
    }

    public function daftarMotorTambah()
    {
        return view('admin/daftar-motor-tambah');
    }

    public function createMotor()
    {
        $data = $this->request->getPost();
        $file = $this->request->getFile('cover');

        if ($file && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['cover'] = $path;
        }

        $motorModel = new MotorsModel();

        if ($motorModel->insert($data, false)) {
            return redirect()->to('admin/daftar-motor')->with('berhasil', 'Data berhasil disimpan!');
        } else {
            return redirect()->to('admin/daftar-motor')->with('gagal', 'Data gagal disimpan!');
        }
    }

    public function daftarMotorEdit($id)
    {
        $motorModel = new MotorsModel();
        $motor = $motorModel->find($id);
    
        if (!$motor) {
            return redirect()->to('admin/daftar-motor')->with('gagal', 'Data motor tidak ditemukan!');
        }
    
        return view('admin/daftar-motor-edit', ['motor' => $motor]);
    }
    
    public function change($id)
    {
        $motorModel = new MotorsModel(); 
        $existingmotor = $motorModel->find($id); 
    
        if (!$existingmotor) {
            return redirect()->to('admin/daftar-motor')->with('gagal', 'Data motor tidak ditemukan!');
        }
    
        $data = $this->request->getPost(); 
        $file = $this->request->getFile('cover');
    
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $path = $file->store('images');
            $data['cover'] = $path; 
        } else {
            $data['cover'] = $existingmotor['cover'];
        }
    
        if ($motorModel->update($id, $data)) {
            return redirect()->to('admin/daftar-motor')->with('berhasil', 'Data berhasil diperbarui!');
        } else {
            return redirect()->to('admin/daftar-motor')->with('gagal', 'Data gagal diperbarui!');
        }
    }
    public function hapusMotor($id)
    {
        $motorModel = new \App\Models\MotorsModel();
    
        $motor = $motorModel->find($id);
    
        if ($motor) {
            $motorModel->delete($id);
    

            return redirect()->to('/admin/daftar-motor')->with('success', 'Motor berhasil dihapus.');
        }

        return redirect()->to('/admin/daftar-motor')->with('error', 'Motor tidak ditemukan.');
    }
    
    

    public function transaksi()
    {
        return view('admin/transaksi');
    }
 
    public function transaksiUbahStatus()
    {
        return view('admin/transaksi-ubah-status');
    }

    public function transaksiHapus()
    {
        return view('admin/transaksi-hapus');
    }

    public function pelanggan()
    {
        return view('admin/pelanggan');
    }

    public function pelangganHapus()
    {
        return view('admin/pelanggan-hapus');
    }
}