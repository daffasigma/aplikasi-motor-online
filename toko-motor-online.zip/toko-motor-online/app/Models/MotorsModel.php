<?php

namespace App\Models;

use CodeIgniter\Model;

class MotorsModel extends Model
{
    protected $table            = 'motor'; 
    protected $primaryKey       = 'id';  
    protected $useAutoIncrement = true;  
    protected $returnType       = 'array'; 
    protected $useSoftDeletes   = false;  
    protected $protectFields    = true;   
    protected $allowedFields    = ['merek', 'tipe', 'tahun', 'warna', 'harga', 'mesin','cover']; 

    protected bool $allowEmptyInserts = false; 
    protected bool $updateOnlyChanged = true; 

    protected array $casts = [
        'tahun' => 'integer', 
        'harga' => 'integer', 
    ];
    protected array $castHandlers = [];

   
    protected $useTimestamps = false; 
    protected $dateFormat    = 'datetime'; 
    protected $createdField  = 'created_at'; 
    protected $updatedField  = 'updated_at'; 
    protected $deletedField  = 'deleted_at';

    
    protected $validationRules      = [
        'merek'  => 'required|min_length[3]|max_length[225]',  
        'tipe'   => 'required|min_length[3]|max_length[225]',  
        'tahun'  => 'required|integer|min_length[4]|max_length[4]', 
        'warna'  => 'required|min_length[3]|max_length[50]',   
        'harga'  => 'required|integer|min_length[1]|max_length[16]', 
        'mesin'  => 'required|min_length[3]|max_length[50]',   
    ]; 
    
    protected $validationMessages   = []; 
    protected $skipValidation       = false; 

    protected $cleanValidationRules = true;

    
    protected $allowCallbacks = true;
    protected $beforeInsert   = [];
    protected $afterInsert    = [];
    protected $beforeUpdate   = [];
    protected $afterUpdate    = [];
    protected $beforeFind     = [];
    protected $afterFind      = [];
    protected $beforeDelete   = [];
    protected $afterDelete    = [];
}
