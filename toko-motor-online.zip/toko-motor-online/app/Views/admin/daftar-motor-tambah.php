<?= $this->extend('admin/template')?>

<?= $this->section('main')?>
<h2 class="mb-5">Tambah Motor</h2>

<div class="w-50">
    <form action="<?= base_url('admin/daftar-motor/create')?>" enctype="multipart/form-data" method="post">
        <div class="mb-3">
            <label for="merek">merek</label>
            <input type="text" class="form-control" name="merek" id="merek">
        </div>
        <div class="mb-3">
            <label for="tipe">tipe</label>
            <input type="text" class="form-control" name="tipe" id="tipe">
        </div>
        <div class="mb-3">
            <label for="tahun">tahun</label>
            <input type="text" class="form-control" name="tahun" id="tahun">
        </div>
        <div class="mb-3">
            <label for="warna">warna</label>
            <input type="text" class="form-control" name="warna" id="warna">
        </div>
        <div class="mb-3">
            <label for="harga">harga</label>
            <input type="text" class="form-control" name="harga" id="harga">
        </div>
        <div class="mb-3">
            <label for="mesin">mesin</label>
            <input type="text" class="form-control" name="mesin" id="mesin">
        </div>
        <div class="mb-3">
            <label for="cover">cover</label>
            <input type="file" name="cover" id="cover" class="form-control">
        </div>
        <div class="mb-3">
            <a href="<?= base_url('admin/daftar-motor')?>" class="btn btn-secondary">Kembali</a>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
    </form>
</div>

<?= $this->endSection()?>