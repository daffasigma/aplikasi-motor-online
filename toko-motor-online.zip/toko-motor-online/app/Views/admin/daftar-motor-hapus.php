<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Motor</title>
    <link rel="stylesheet" href="/path/to/your/css/styles.css"> 
</head>
<body>
    <div class="container">
        <h1>Konfirmasi Hapus Motor</h1>

        <?php if (isset($sepatu)): ?>
            <p>Apakah Anda yakin ingin menghapus motor dengan data berikut?</p>
            <ul>
                <li><strong>Nama:</strong> <?= htmlspecialchars($motor['nama']); ?></li>
                <li><strong>Harga:</strong> Rp <?= number_format($motor['harga'], 2, ',', '.'); ?></li>
                <li><strong>Stok:</strong> <?= htmlspecialchars($motor['stok']); ?></li>
            </ul>

            <form action="/admin/daftar-motor/hapus/<?= $motor['id']; ?>" method="post">
                <?= csrf_field(); ?> 
                <button type="submit" class="btn btn-danger">Hapus</button>
                <a href="/admin/daftar-sepatu" class="btn btn-secondary">Batal</a>
            </form>
        <?php else: ?>
            <p>Data motor tidak ditemukan.</p>
            <a href="/admin/daftar-sepatu" class="btn btn-secondary">Kembali ke Daftar Motor</a>
        <?php endif; ?>
    </div>
</body>
</html>