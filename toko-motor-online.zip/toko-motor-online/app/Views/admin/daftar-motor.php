<?= $this->extend('admin/template'); ?>

<?= $this->section('main'); ?>

<h2 class="mb-5">Daftar Motor</h2>

<div class="mb-3">
    <a href="<?= base_url('admin/daftar-motor/tambah')?>" class="btn btn-primary">Tambah Motor</a>
</div>

<div class="mb-5">
    <table class="table table-stripped">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">merek</th>
                <th scope="col">tipe</th>
                <th scope="col">tahun</th>
                <th scope="col">warna</th>
                <th scope="col">harga</th>
                <th scope="col">Mesin</th>
                <th scope="col">Gambar</th>
                <th scope="col">Aksi</th>

            </tr>
        </thead>
        <tbody>
            <?php foreach($motor as $motors): ?>
            <tr>
                <th scope="row"><?=$motors['id']?></th>
                <td><?=$motors['merek']?></td>
                <td><?=$motors['tipe']?></td>
                <td><?=$motors['tahun']?></td>
                <td><?=$motors['warna']?></td>
                <td><?=$motors['harga']?></td>
                <td><?=$motors['mesin']?></td>
                <td>
                    <img src="<?= base_url($motors['cover'])?>" alt="" style="width: 150px; height: auto;">
                </td>
               
                <td>
                    <a href="<?= base_url('admin/daftar-motor/edit')?>/<?=$motors['id']?>" class="btn btn-success">Edit</a>
                    <a href="<?= base_url('admin/daftar-motor/hapus')?>/<?=$motors['id']?>" class="btn btn-danger">Hapus</a>
                </td>
            </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</div>

<?= $this->endSection();?>