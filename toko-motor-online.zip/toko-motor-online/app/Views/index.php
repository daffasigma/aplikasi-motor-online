<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Toko Motor</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="<?= base_url()?>css/style.css">
  </head>
  <body>
    <div class="container">
      <div class="row mb-5">
        <div class="col-12 text-end">
          <a href="<?= base_url() ?>chart" class="btn btn-secondary">Keranjang belanja <span class="badge text-bg-warning">4</span></a>
        </div>
      </div>
      <div class="row bg-primary-subtle mb-5">
        <div class="col-6 p-5">
          <h1>Selamat Datang di Toko Motor Online</h1>
          <p>Kami menyediakan berbagai jenis motor</p>
          <a href="#" class="btn btn-success">Lihat Produk</a>
        </div>
        <div class="col-6 p-5">
          <h1>Temukan motor favorit Anda!</h1>
          <form action="">
            <div class="mb-3">
              <input
                type="text"
                class="form-control"
                placeholder="Merek Motor"
              />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="jenis Motor" />
            </div>
            <div class="mb-3">
              <input type="text" class="form-control" placeholder="CC motor" />
            </div>
            <div class="mb-3">
              <button class="btn btn-primary">Cari</button>
            </div>
          </form>
        </div>
      </div>

      <h2>Motor Best Seller</h2>
      <div class="row mb-5 g-3">
        <div class="col-3">
          <div class="card">
            <img src="images/poto1.jpg" class="card-img-top" alt="..." />
            <div class="card-body">
              <h5 class="card-title">Motor Matic Honda Terbaru</h5>
              <p class="card-text">
                Rp 35.000,000,-
              </p>
              <a href="#" class="btn btn-primary">Add to chart</a>
            </div>
          </div>
        </div>
        <div class="col-3">
            <div class="card">
              <img src="images/poto2.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Motor CBR 150</h5>
                <p class="card-text">
                  Rp 36.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <img src="images/poto3.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Motor Matic AEROX</h5>
                <p class="card-text">
                  Rp 34.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <img src="<?= base_url() ?>images/poto4.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Motor Nmax</h5>
                <p class="card-text">
                  Rp 33.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <img src="<?= base_url() ?>images/poto5.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Motor Bebek Yamaha</h5>
                <p class="card-text">
                  Rp 30.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <img src="<?= base_url() ?>images/poto6.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Sepeda Motor </h5>
                <p class="card-text">
                  Rp 27.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <img src="<?= base_url() ?>images/poto7.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Motor Vario</h5>
                <p class="card-text">
                  Rp 28.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
          <div class="col-3">
            <div class="card">
              <img src="<?= base_url() ?>images/poto8.jpg" class="card-img-top" alt="..." />
              <div class="card-body">
                <h5 class="card-title">Motor Yamaha</h5>
                <p class="card-text">
                  Rp 29.000,000,-
                </p>
                <a href="#" class="btn btn-primary">Add to chart</a>
              </div>
            </div>
          </div>
      </div>
    </div>

    <footer class="bg-danger-subtle py-3">
        <div class="container">
            Copyright 2024. Toko Motor Online . All Rights reserved.
        </div>
    </footer>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"
    ></script>
  </body>
</html>
